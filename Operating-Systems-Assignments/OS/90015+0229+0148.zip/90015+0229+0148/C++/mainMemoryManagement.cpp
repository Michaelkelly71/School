/*
ID              NAME
219cs01090015   OSEI MICHAEL KELLY
0000000000029   KOBBINA AMOAH
0000000000148   BADOLO DEBORA

A program to simulate memory management techniques
**/


//Adding the library iostream which allows the user to input data and see outputs on the screen 
#include <iostream>
#include "Contigious.cpp"
#include "Paging.cpp"
#include "NonPreemptive.cpp"
#include "MultiLevel.cpp"

//Helps the user to use the input and the output streams
using namespace std;

//the whole code is executed in the "main" function
int main(){

    //Creating an object of the class Contigious
    Contigious fits;
    Paging tech;
    NonPreemptive cpu;
    MultiLevel multi;

    //Declaration and initialization of variables
    int memoryProcessRequired, blockSize, noOfBlocks, externalFragmentation,numberOfProcesses, mp[10],totalInternalFragmentation=0; 
    int i,p=0;
    int temp,n=0; char ch = 'y';
    char again = 'y';

    //Displays output to the screen
            cout << "\n\n"
            "\t**************************************************************************\n"
            "\tA program to simulate memory management techniques Positive Intergers Only\n" 
            "\t**************************************************************************"<< endl;
            
            
    do  {
        cout << 
        "\n1. Multiprogramming with a Fixed number of task  \n" <<
        "2. Multiprogramming with a Variable number of task\n"
        "3. Contiguous memory allocation techniques\n"
        "4. Paging technique of memory management.\n"
        "5. Non-preemptive CPU scheduling algorithms\n"
        "6. Multi-level queue scheduling algorithm\n"
        << endl;

        //choice is declared
        int choice;
        cout << "\nChoice (Positive Integers Only Please): ";
        //choice is input here
        cin >> choice;

        //if statement checking the condition that the input choice is 1
        if (choice == 1)
        {
            //Promptting the use to give inputs
            cout << "\nMFT\nEnter the total memory available (in Bytes) -- "; cin >> memoryProcessRequired;

            cout << "Enter the block size (in Bytes) -- ";cin >> blockSize;

            //computation for the number of block size and external Fragmentation
            noOfBlocks = memoryProcessRequired / blockSize;
            externalFragmentation = memoryProcessRequired - noOfBlocks * blockSize;

            //Promptting the use to give input
            cout << "\nEnter the number of processes -- "; cin >> numberOfProcesses;

            // This is a for loop that accepts the memory required for the number of processes
            for(i=0; i<numberOfProcesses; i++)
            {
            cout << "Enter memory required for process " << (i+1) << " bin Bytes)-- " ; 
            cin >> mp[i];
            }

            //Displaying the number of blocks available in memory
            cout << "\nNo. of Blocks available in memory -- " << noOfBlocks;

            //Displaying output
            cout << "\n\nPROCESS\t\tMEMORY REQUIRED\t\t ALLOCATED\tINTERNAL FRAGMENTATION" << endl;
            cout << "------------------------------------------------------------------------------" << endl;

            // for loop check the condition that the number of processes "and" the number of blocks a true
            for(i=0;i<numberOfProcesses && p<noOfBlocks;i++)
            {
                //Displaying the output in a neat format with "\t"
                cout << "\n" << i+1 << "\t\t" << mp[i];
                if(mp[i] > blockSize){
                    cout << "\t\t\t NO\t\t\t---";
                }

                else{
                    cout << "\t\t\t YES\t\t\t" << blockSize-mp[i];
                    totalInternalFragmentation = totalInternalFragmentation + blockSize-mp[i];
                    p++;
                }

        }



        //final output based on computation and execution
        if(i<numberOfProcesses){
            cout << "\n\nMemory is Full, Remaining Processes cannot be accomodated" << endl;
            cout << "\n\nTotal Internal Fragmentation is " << totalInternalFragmentation; 
            cout << "\nTotal External Fragmentation is " << externalFragmentation; 
            
        }


        }
        else if(choice == 2)
        {
            //Promting the user for input
            cout << "\nMVT\nEnter the total memory available (in Bytes)-- "; 
                cin >> memoryProcessRequired;
                temp=memoryProcessRequired;

                //gives the user a chance to continue to input memory required for process
                for(i=0;ch=='y';i++,n++)
                {
                    cout << "\n\nEnter memory required for process  " << (i+1) << " (in Bytes) -- "; 
                    cin >> mp[i];
                    
                    //is statment uses to check whether temp is less than or equal to memory required for process
                    if(mp[i]<=temp)
                    {
                        //Displays the information below
                        cout << "\nMemory is allocated for Process " << (i+1) << endl; 
                        temp = temp - mp[i];
                        cout << "\nDo you want to continue(y/n) -- "; 
                        cin >> ch;
                        
                    } else {
                        
                        //clear or breaks the program 
                        break; 
                    }
                    
                }

                // displays the information to the screen 
                cout << "\n\nMemory is Full" << endl;
                cout << "\n\nTotal Memory Available --" << memoryProcessRequired << endl;
                cout << "\n\nPROCESS\t\t MEMORY ALLOCATED "<< endl;
                cout << "---------------------------------" << endl;

                //Displaying the output in a neat format with "\t"
                for(i=0;i<n;i++){
                    cout << "\n " << (i+1) << "\t\t " << (mp[i]) << endl;
                    cout << "" << endl;

                }

                cout << "" << endl;

                //final output based on computation and execution
                cout << "\n\nTotal Memory Allocated is " << (memoryProcessRequired-temp) << endl;
                cout << "Total External Fragmentation is " << temp;    


        //this portion is executed only if the choice input above is not 1 or 2
        }
        else if (choice == 3)
        {
            fits.contigious(choice);
        }

        else if (choice == 4)
        {
            tech.technique();
        }

        else if (choice == 5)
        {
            cpu.list(choice);
        }
        
        else if (choice == 6)
        {
            multi.level();
        }
        else{
            cout << "Wrong Input Re-run the program and try again!!!" << endl;
                return 0;
        }

                    string a;
                    cout << "\n\nAnother Test???: ";
                    cin >> again;
                } 

    while (again == 'y');

}
