#include <iostream>
#include <iomanip>


using namespace std
;
class Bankers{

        struct file
    {
        int all[10]; 
        int maxx[10]; 
        int need[10]; 
        int flag;
    };

    public : void main() {
        struct file f[10];
        int fl;
        int i, j, k, p, b, n, r, g, cnt=0, id, newr; int avail[10],seq[10];

        cout << "\nEnter number of processes -- "; 
        cin >> n;
        cout << "Enter number of resources -- "; 
        cin >> r;

        for(i=0;i<n;i++)
        {
            cout << "\nEnter details for P" << i; 
            cout << "\nEnter allocation\t -- \t"; 
            
            for(j=0;j<r;j++)
            cin >> f[i].all[j]; 

            cout << "Enter Max\t\t -- \t";
            
            for(j=0;j<r;j++) 
            cin >> f[i].maxx[j];
            f[i].flag=0; 
        }

        cout << "\nEnter Available Resources\t -- \t"; 
        
        for(i=0;i<r;i++)
        cin >> avail[i];
        cout << "\nEnter New Request Details -- "; 
        cout << "\nEnter pid \t -- \t"; 
        
        cin >> id;
        cout << "Enter Request for Resources \t -- \t"; 
        
        for(i=0;i<r;i++)
        {
            cin >> newr; 
            f[id].all[i] += newr;
            avail[i]=avail[i] - newr;
        }

        for(i=0;i<n;i++) {
            for(j=0;j<r;j++) {
                f[i].need[j]=f[i].maxx[j]-f[i].all[j]; 
                if(f[i].need[j]<0)
                f[i].need[j]=0;
            }
        }

        cnt=0;
        fl=0; 
        while(cnt!=n) {
            g=0; 
            for(j=0;j<n;j++) 
            {
                if(f[j].flag==0) 
                {
                    b=0; 
                    for(p=0;p<r;p++) 
                    {
                        if(avail[p]>=f[j].need[p]) 
                            b=b+1;
                        else
                            b=b-1;
                    }

                    if(b==r) 
                    {
                        
                        cout << "\nP is visited" << j; 
                        seq[fl++]=j;
                        f[j].flag=1; 
                        for(k=0;k<r;k++)
                            avail[k]=avail[k]+f[j].all[k]; 
                        cnt=cnt+1;
                        cout << "("; 
                        for(k=0;k<r;k++)
                            cout << avail[k]; 
                        cout << ")";
                        g=1; 
                    }
                }
            }
            if(g==0) 
            {
                cout << "\n REQUEST NOT GRANTED -- DEADLOCK OCCURRED" << endl; 
                cout << "\n SYSTEM IS IN UNSAFE STATE" << endl; 
                goto y;
            }
        }

        cout << "\n\nSYSTEM IS IN SAFE STATE" << endl; 
        cout << "\nThe Safe Sequence is -- ("; 
        for(i=0;i<fl;i++)
            cout << "P" << seq[i] << " "; 
            cout << ")";
        y: cout << "\nProcess\t\tAllocation\t\tMax\t\t\tNeed\n"; 
        for(i=0;i<n;i++)
        {
            cout << "P" << i <<"\t"; 
            for(j=0;j<r;j++)
                cout << setw(6) << f[i].all[j]; 
            for(j=0;j<r;j++)
                cout << setw(9) << f[i].maxx[j]; 
            for(j=0;j<r;j++)
                cout << setw(6) << f[i].need[j]; 
            cout << "\n";
        }
    }

};

    