# payroll-management-system
Based on Html, CSS, JavaScript, PHP and MySql

Login Page - index.php
username - Kelly
password - Kelly123

